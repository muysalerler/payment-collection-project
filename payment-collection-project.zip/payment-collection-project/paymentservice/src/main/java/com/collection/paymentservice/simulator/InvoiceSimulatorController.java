package com.collection.paymentservice.simulator;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/simulator")
public class InvoiceSimulatorController {

    private final InvoiceSimulatorService simulatorService;

    public InvoiceSimulatorController(InvoiceSimulatorService simulatorService) {
        this.simulatorService = simulatorService;
    }

    @PostMapping("/start")
    public String startSimulation() {
        simulatorService.enable();
        return "✅ Simulation started.";
    }

    @PostMapping("/stop")
    public String stopSimulation() {
        simulatorService.disable();
        return "⛔ Simulation stopped.";
    }

    @GetMapping("/status")
    public String getStatus() {
        return simulatorService.isEnabled() ? "✅ Simulation is active." : "⛔ Simulation is inactive.";
    }
}
