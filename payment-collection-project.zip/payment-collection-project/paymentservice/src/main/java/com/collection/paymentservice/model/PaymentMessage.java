package com.collection.paymentservice.model;

import java.math.BigDecimal;

public class PaymentMessage {

    private Long invoiceId;
    private BigDecimal amount;
    private String currency;
    private String paymentDate;

    @Override
    public String toString() {
        return "PaymentMessage{" +
                "invoiceId=" + invoiceId +
                ", amount=" + amount +
                ", currency='" + currency + '\'' +
                ", paymentDate='" + paymentDate + '\'' +
                '}';
    }


    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal bigDecimal) {
        this.amount = bigDecimal;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {this.paymentDate = paymentDate;}


}
