package com.collection.paymentservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.collection.paymentservice.entity.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
	List<Invoice> findByStatus(Integer status);
	List<Invoice> findByCurrency(String currency);
	List<Invoice> findByStatusAndCurrency(Integer status, String currency);

}
