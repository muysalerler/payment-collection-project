package com.collection.paymentservice.controller;

import com.collection.paymentservice.entity.Invoice;
import com.collection.paymentservice.kafka.PaymentProducer;
import com.collection.paymentservice.model.PaymentMessage;
import com.collection.paymentservice.model.PaymentRequest;
import com.collection.paymentservice.repository.InvoiceRepository;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final PaymentProducer paymentProducer;
    private final InvoiceRepository invoiceRepository;

    public PaymentController(PaymentProducer paymentProducer, InvoiceRepository invoiceRepository) {
        this.paymentProducer = paymentProducer;
        this.invoiceRepository = invoiceRepository;
    }

    @PostMapping
    public ResponseEntity<String> makePayment(@RequestBody PaymentRequest request) {

        Invoice invoice = invoiceRepository.findById(request.getInvoiceId())
                .orElseThrow(() -> new EntityNotFoundException("Invoice not found: " + request.getInvoiceId()));

        invoice.setStatus(1);
        invoiceRepository.save(invoice);

        PaymentMessage message = new PaymentMessage();
        message.setInvoiceId(request.getInvoiceId());
        message.setAmount(request.getAmount());
        message.setCurrency(request.getCurrency());
        message.setPaymentDate(LocalDate.now().toString());

        paymentProducer.sendPayment(message);

        return ResponseEntity.ok("Payment sent to Kafka and invoice updated.");
    }
}




















