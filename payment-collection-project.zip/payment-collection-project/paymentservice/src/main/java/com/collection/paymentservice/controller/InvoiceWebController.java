package com.collection.paymentservice.controller;

import com.collection.paymentservice.entity.Invoice;
import com.collection.paymentservice.kafka.PaymentProducer;
import com.collection.paymentservice.model.PaymentMessage;
import com.collection.paymentservice.repository.InvoiceRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
public class InvoiceWebController {

    private static final Logger log = LoggerFactory.getLogger(InvoiceWebController.class);

    private final InvoiceRepository invoiceRepository;
    private final PaymentProducer paymentProducer;

    public InvoiceWebController(InvoiceRepository invoiceRepository, PaymentProducer paymentProducer) {
        this.invoiceRepository = invoiceRepository;
        this.paymentProducer = paymentProducer;
    }

    @GetMapping("/")
    public String home() {
        log.info("🏠 Home page viewed.");
        return "index"; // templates/index.html
    }

    @GetMapping("/invoices")
    public String getInvoices(Model model) {
        List<Invoice> invoices = invoiceRepository.findAll();
        log.info("📄 {} invoices listed.", invoices.size());
        model.addAttribute("invoices", invoices);
        return "invoices";
    }

    @GetMapping("/pay/{id}")
    public String payInvoice(@PathVariable Long id) {
        log.info("💳 Payment process started → Invoice ID: {}", id);

        Optional<Invoice> optionalInvoice = invoiceRepository.findById(id);

        if (optionalInvoice.isPresent()) {
            Invoice invoice = optionalInvoice.get();

            if (invoice.getStatus() == 0) {
                invoice.setStatus(1);
                invoiceRepository.save(invoice);

                PaymentMessage message = new PaymentMessage();
                message.setInvoiceId(invoice.getInvoiceId());
                message.setAmount(invoice.getAmount());
                message.setCurrency(invoice.getCurrency());
                message.setPaymentDate(LocalDate.now().toString());

                paymentProducer.sendPayment(message);

                log.info("✅ Payment sent to Kafka and invoice closed: {}", message);
            } else {
                log.warn("⚠️ Invoice already closed: ID {}", id);
            }
        } else {
            log.error("❌ Invoice not found: ID {}", id);
        }

        return "redirect:/invoices?success=true";
    }
}
