package com.collection.paymentservice.simulator;

import com.collection.paymentservice.entity.Invoice;
import com.collection.paymentservice.kafka.PaymentProducer;
import com.collection.paymentservice.model.PaymentMessage;
import com.collection.paymentservice.repository.InvoiceRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Random;

@Service
public class InvoiceSimulatorService {

    private static final Logger log = LoggerFactory.getLogger(InvoiceSimulatorService.class);

    private final InvoiceRepository invoiceRepository;
    private final PaymentProducer paymentProducer;

    private final Random random = new Random();
    private boolean enabled = false;

    public InvoiceSimulatorService(InvoiceRepository invoiceRepository, PaymentProducer paymentProducer) {
        this.invoiceRepository = invoiceRepository;
        this.paymentProducer = paymentProducer;
    }

    @Scheduled(fixedRate = 10000)
    public void generateInvoiceAndSendPayment() {
        if (!enabled) return;

        BigDecimal amount = BigDecimal.valueOf(100 + random.nextInt(400));

        Invoice invoice = new Invoice();
        invoice.setAmount(amount);
        invoice.setCurrency(random.nextBoolean() ? "TRY" : "USD");
        invoice.setStatus(0);
        invoiceRepository.save(invoice);

        PaymentMessage message = new PaymentMessage();
        message.setInvoiceId(invoice.getInvoiceId());
        message.setAmount(invoice.getAmount());
        message.setCurrency(invoice.getCurrency());
        message.setPaymentDate(LocalDate.now().toString());


        log.info("💸 Auto-generated invoice created and sent to Kafka: {}", message);
    }

    public void enable() {
        this.enabled = true;
        log.info("✅ Automatic invoice generation started.");
    }

    public void disable() {
        this.enabled = false;
        log.info("⛔ Automatic invoice generation stopped.");
    }

    public boolean isEnabled() {
        return enabled;
    }
}
