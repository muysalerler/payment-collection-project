package com.collection.paymentservice.controller;

import com.collection.paymentservice.entity.Invoice;
import com.collection.paymentservice.repository.InvoiceRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceRepository invoiceRepository;
    
    public InvoiceController(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @GetMapping
    public ResponseEntity<List<Invoice>> getInvoices(
            @RequestParam(required = false) Integer status,
            @RequestParam(required = false) String currency) {

        List<Invoice> result;

        if (status != null && currency != null) {
            result = invoiceRepository.findByStatusAndCurrency(status, currency.toUpperCase());
        } else if (status != null) {
            result = invoiceRepository.findByStatus(status);
        } else if (currency != null) {
            result = invoiceRepository.findByCurrency(currency.toUpperCase());
        } else {
            result = invoiceRepository.findAll();
        }

        return ResponseEntity.ok(result);
    }
}
