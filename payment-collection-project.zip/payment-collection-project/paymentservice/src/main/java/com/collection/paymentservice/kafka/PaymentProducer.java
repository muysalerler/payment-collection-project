package com.collection.paymentservice.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.collection.paymentservice.model.PaymentMessage;

@Service
public class PaymentProducer {

    private static final Logger log = LoggerFactory.getLogger(PaymentProducer.class);
    private final KafkaTemplate<String, PaymentMessage> kafkaTemplate;

    public PaymentProducer(KafkaTemplate<String, PaymentMessage> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendPayment(PaymentMessage message) {
        kafkaTemplate.send("payment-request", message);
        log.info("Message sent to Kafka: {}", message);
    }
}







































