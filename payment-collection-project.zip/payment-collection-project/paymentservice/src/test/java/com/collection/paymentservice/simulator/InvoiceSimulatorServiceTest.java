package com.collection.paymentservice.simulator;

import com.collection.paymentservice.entity.Invoice;
import com.collection.paymentservice.kafka.PaymentProducer;
import com.collection.paymentservice.repository.InvoiceRepository;
import com.collection.paymentservice.simulator.InvoiceSimulatorService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;

import static org.mockito.Mockito.*;

public class InvoiceSimulatorServiceTest {

    private InvoiceRepository invoiceRepository;
    private PaymentProducer paymentProducer;
    private InvoiceSimulatorService service;

    @BeforeEach
    public void setUp() {
        invoiceRepository = mock(InvoiceRepository.class);
        paymentProducer = mock(PaymentProducer.class);
        service = new InvoiceSimulatorService(invoiceRepository, paymentProducer);
    }

    @Test
    public void test_generateInvoiceAndSendPayment_doesNothing_whenDisabled() {
        service.generateInvoiceAndSendPayment();

        verifyNoInteractions(invoiceRepository);
        verifyNoInteractions(paymentProducer);
    }

    @Test
    public void test_generateInvoiceAndSendPayment_createsInvoice_whenEnabled() {
        service.enable();

        service.generateInvoiceAndSendPayment();

        verify(invoiceRepository, times(1)).save(any(Invoice.class));
        verify(paymentProducer, times(1)).sendPayment(any());
    }

    @Test
    public void test_invoiceContainsValidFields_whenEnabled() {
        service.enable();

        service.generateInvoiceAndSendPayment();

        ArgumentCaptor<Invoice> captor = ArgumentCaptor.forClass(Invoice.class);
        verify(invoiceRepository).save(captor.capture());

        Invoice invoice = captor.getValue();
        assert invoice.getAmount().compareTo(BigDecimal.ZERO) > 0;
        assert invoice.getStatus() == 0;
        assert invoice.getCurrency().equals("TRY") || invoice.getCurrency().equals("USD");
    }
}
