package com.collection.paymentservice.controller;

import com.collection.paymentservice.controller.PaymentController;
import com.collection.paymentservice.entity.Invoice;
import com.collection.paymentservice.kafka.PaymentProducer;
import com.collection.paymentservice.model.PaymentRequest;
import com.collection.paymentservice.repository.InvoiceRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PaymentController.class)
public class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InvoiceRepository invoiceRepository;

    @MockBean
    private PaymentProducer paymentProducer;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testMakePayment_returnsOk_whenInvoiceExists() throws Exception {
        Invoice invoice = new Invoice();
        invoice.setInvoiceId(123L);
        invoice.setAmount(BigDecimal.valueOf(250.75));
        invoice.setCurrency("TRY");
        invoice.setStatus(0);

        Mockito.when(invoiceRepository.findById(123L)).thenReturn(Optional.of(invoice));

        PaymentRequest request = new PaymentRequest();
        request.setInvoiceId(123L);
        request.setAmount(BigDecimal.valueOf(250.75));
        request.setCurrency("TRY");

        mockMvc.perform(post("/api/payment")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    public void testMakePayment_returnsNotFound_whenInvoiceMissing() throws Exception {
        Mockito.when(invoiceRepository.findById(999L)).thenReturn(Optional.empty());

        PaymentRequest request = new PaymentRequest();
        request.setInvoiceId(999L);
        request.setAmount(BigDecimal.valueOf(100));
        request.setCurrency("TRY");

        mockMvc.perform(post("/api/payment")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound());
    }
}
