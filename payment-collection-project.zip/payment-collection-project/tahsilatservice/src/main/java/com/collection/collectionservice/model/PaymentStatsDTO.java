package com.collection.collectionservice.model;

import java.math.BigDecimal;
import java.util.List;

public class PaymentStatsDTO {
    private BigDecimal totalTry;
    private BigDecimal totalUsd;
    private List<SimplePaymentDTO> lastTryPayments;
    private List<SimplePaymentDTO> lastUsdPayments;

    public BigDecimal getTotalTry() {
        return totalTry;
    }

    public void setTotalTry(BigDecimal totalTry) {
        this.totalTry = totalTry;
    }

    public BigDecimal getTotalUsd() {
        return totalUsd;
    }

    public void setTotalUsd(BigDecimal totalUsd) {
        this.totalUsd = totalUsd;
    }

    public List<SimplePaymentDTO> getLastTryPayments() {
        return lastTryPayments;
    }

    public void setLastTryPayments(List<SimplePaymentDTO> lastTryPayments) {
        this.lastTryPayments = lastTryPayments;
    }

    public List<SimplePaymentDTO> getLastUsdPayments() {
        return lastUsdPayments;
    }

    public void setLastUsdPayments(List<SimplePaymentDTO> lastUsdPayments) {
        this.lastUsdPayments = lastUsdPayments;
    }
}
