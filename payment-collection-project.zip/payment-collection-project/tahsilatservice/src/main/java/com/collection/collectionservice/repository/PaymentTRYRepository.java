package com.collection.collectionservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.collection.collectionservice.entity.PaymentTRY;

public interface PaymentTRYRepository extends JpaRepository<PaymentTRY, Long> {
}
