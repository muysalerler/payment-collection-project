package com.collection.collectionservice.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.collection.collectionservice.model.PaymentRequest;

@Service
public class PaymentConsumer {

    private static final Logger log = LoggerFactory.getLogger(PaymentConsumer.class);

    @KafkaListener(topics = "payment-topic", groupId = "collection-group")
    public void consume(PaymentRequest request) {
        log.info("Payment received for processing: {}", request);
    }
}




