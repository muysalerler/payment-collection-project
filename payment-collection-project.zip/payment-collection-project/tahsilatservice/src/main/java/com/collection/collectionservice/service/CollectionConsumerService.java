package com.collection.collectionservice.service;

import com.collection.collectionservice.entity.PaymentTRY;
import com.collection.collectionservice.entity.PaymentUSD;
import com.collection.collectionservice.model.PaymentMessage;
import com.collection.collectionservice.repository.PaymentTRYRepository;
import com.collection.collectionservice.repository.PaymentUSDRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class CollectionConsumerService {

    private static final Logger logger = LoggerFactory.getLogger(CollectionConsumerService.class);
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final PaymentTRYRepository paymentTRYRepository;
    private final PaymentUSDRepository paymentUSDRepository;

    public CollectionConsumerService(PaymentTRYRepository paymentTRYRepository, PaymentUSDRepository paymentUSDRepository) {
        this.paymentTRYRepository = paymentTRYRepository;
        this.paymentUSDRepository = paymentUSDRepository;
    }

    @KafkaListener(topics = "payment-request", groupId = "collection-group")
    public void consumePaymentMessage(PaymentMessage message) {
        logger.info("✅ New payment message received: {}", message);

        if ("TRY".equalsIgnoreCase(message.getCurrency())) {
            PaymentTRY paymentTRY = new PaymentTRY();
            paymentTRY.setInvoiceId(message.getInvoiceId());
            paymentTRY.setAmount(message.getAmount());
            paymentTRY.setPaymentDate(LocalDate.parse(message.getPaymentDate(), FORMATTER));

            paymentTRYRepository.save(paymentTRY);
            logger.info("💰 TRY payment saved. Invoice ID: {}", message.getInvoiceId());

        } else if ("USD".equalsIgnoreCase(message.getCurrency())) {
            PaymentUSD paymentUSD = new PaymentUSD();
            paymentUSD.setInvoiceId(message.getInvoiceId());
            paymentUSD.setAmount(message.getAmount());
            paymentUSD.setPaymentDate(LocalDate.parse(message.getPaymentDate(), FORMATTER));

            paymentUSDRepository.save(paymentUSD);
            logger.info("💵 USD payment saved. Invoice ID: {}", message.getInvoiceId());

        } else {
            logger.error("❌ Unknown currency type: {} — message could not be processed.", message.getCurrency());
        }
    }
}










