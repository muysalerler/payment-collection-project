package com.collection.collectionservice.controller;

import com.collection.collectionservice.entity.PaymentTRY;
import com.collection.collectionservice.entity.PaymentUSD;
import com.collection.collectionservice.model.SimplePaymentDTO;
import com.collection.collectionservice.repository.PaymentTRYRepository;
import com.collection.collectionservice.repository.PaymentUSDRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class PaymentStatsController {

    private static final Logger log = LoggerFactory.getLogger(PaymentStatsController.class);

    private final PaymentTRYRepository tryRepo;
    private final PaymentUSDRepository usdRepo;

    public PaymentStatsController(PaymentTRYRepository tryRepo, PaymentUSDRepository usdRepo) {
        this.tryRepo = tryRepo;
        this.usdRepo = usdRepo;
    }

    @GetMapping("/stats")
    public String getStats(Model model) {
        List<PaymentTRY> tryPayments = tryRepo.findAll();
        List<PaymentUSD> usdPayments = usdRepo.findAll();

        BigDecimal totalTry = tryPayments.stream()
                .map(PaymentTRY::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalUsd = usdPayments.stream()
                .map(PaymentUSD::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        log.info("📊 Total TRY Amount: {} - Total USD Amount: {}", totalTry, totalUsd);

        List<SimplePaymentDTO> lastTry = tryPayments.stream()
                .sorted((a, b) -> {
                    int cmp = b.getPaymentDate().compareTo(a.getPaymentDate());
                    return (cmp != 0) ? cmp : b.getPaymentId().compareTo(a.getPaymentId());
                })
                .limit(5)
                .map(p -> new SimplePaymentDTO(p.getInvoiceId(), p.getAmount(), p.getPaymentDate().toString()))
                .collect(Collectors.toList());

        List<SimplePaymentDTO> lastUsd = usdPayments.stream()
                .sorted((a, b) -> {
                    int cmp = b.getPaymentDate().compareTo(a.getPaymentDate());
                    return (cmp != 0) ? cmp : b.getPaymentId().compareTo(a.getPaymentId());
                })
                .limit(5)
                .map(p -> new SimplePaymentDTO(p.getInvoiceId(), p.getAmount(), p.getPaymentDate().toString()))
                .collect(Collectors.toList());

        log.info("📋 Latest TRY Payments: {}", lastTry);
        log.info("📋 Latest USD Payments: {}", lastUsd);

        model.addAttribute("totalTry", totalTry);
        model.addAttribute("totalUsd", totalUsd);
        model.addAttribute("lastTryPayments", lastTry);
        model.addAttribute("lastUsdPayments", lastUsd);

        return "stats";
    }

    @GetMapping("/api/stats")
    @ResponseBody
    public Map<String, BigDecimal> getStatsJson() {
        BigDecimal totalTry = tryRepo.findAll().stream()
                .map(PaymentTRY::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalUsd = usdRepo.findAll().stream()
                .map(PaymentUSD::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        log.info("📈 /api/stats endpoint called → TRY: {}, USD: {}", totalTry, totalUsd);

        Map<String, BigDecimal> result = new HashMap<>();
        result.put("try", totalTry);
        result.put("usd", totalUsd);
        return result;
    }

    @GetMapping("/api/last-payments")
    @ResponseBody
    public Map<String, List<SimplePaymentDTO>> getLastPayments() {
        List<PaymentTRY> tryPayments = tryRepo.findAll();
        List<PaymentUSD> usdPayments = usdRepo.findAll();

        List<SimplePaymentDTO> lastTry = tryPayments.stream()
                .sorted((a, b) -> {
                    int cmp = b.getPaymentDate().compareTo(a.getPaymentDate());
                    return (cmp != 0) ? cmp : b.getPaymentId().compareTo(a.getPaymentId());
                })
                .limit(5)
                .map(p -> new SimplePaymentDTO(p.getInvoiceId(), p.getAmount(), p.getPaymentDate().toString()))
                .collect(Collectors.toList());

        List<SimplePaymentDTO> lastUsd = usdPayments.stream()
                .sorted((a, b) -> {
                    int cmp = b.getPaymentDate().compareTo(a.getPaymentDate());
                    return (cmp != 0) ? cmp : b.getPaymentId().compareTo(a.getPaymentId());
                })
                .limit(5)
                .map(p -> new SimplePaymentDTO(p.getInvoiceId(), p.getAmount(), p.getPaymentDate().toString()))
                .collect(Collectors.toList());

        log.info("🔄 /api/last-payments endpoint called → Latest TRY: {}, Latest USD: {}", lastTry, lastUsd);

        Map<String, List<SimplePaymentDTO>> result = new HashMap<>();
        result.put("try", lastTry);
        result.put("usd", lastUsd);
        return result;
    }
}
