package com.collection.collectionservice.model;

import java.math.BigDecimal;

import org.springframework.data.repository.query.parser.Part.IgnoreCaseType;

public class SimplePaymentDTO {
    private Long invoiceId;
    private BigDecimal amount;
    private String paymentDate;

    public SimplePaymentDTO() {}

    public SimplePaymentDTO(Long invoiceId, BigDecimal amount, String paymentDate) {
        this.invoiceId = invoiceId;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }
}
