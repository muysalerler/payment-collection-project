package com.collection.collectionservice.kafka;

import com.collection.collectionservice.entity.PaymentTRY;
import com.collection.collectionservice.entity.PaymentUSD;
import com.collection.collectionservice.model.PaymentMessage;
import com.collection.collectionservice.repository.PaymentTRYRepository;
import com.collection.collectionservice.repository.PaymentUSDRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Service
public class KafkaConsumerService {

    private static final Logger log = LoggerFactory.getLogger(KafkaConsumerService.class);
    private final PaymentTRYRepository tryRepository;
    private final PaymentUSDRepository usdRepository;

    public KafkaConsumerService(PaymentTRYRepository tryRepository, PaymentUSDRepository usdRepository) {
        this.tryRepository = tryRepository;
        this.usdRepository = usdRepository;
    }

    @KafkaListener(
        topics = "payment-request",
        groupId = "collection-group",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consume(PaymentMessage message) {
        log.info("✅ Message received from Kafka: {}", message);

        if (message == null) {
            log.error("❌ Received message is null!");
            return;
        }
        LocalDate date = LocalDate.now();
        if (message.getPaymentDate() != null && !message.getPaymentDate().isBlank()) {
            try {
                date = LocalDate.parse(message.getPaymentDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            } catch (DateTimeParseException e) {
                log.warn("❌ Failed to parse payment date: {}", message.getPaymentDate());
            }
        } else {
            log.warn("⚠️ Payment date is null or empty.");
        }

        if ("TRY".equalsIgnoreCase(message.getCurrency())) {
            PaymentTRY payment = new PaymentTRY();
            payment.setInvoiceId(message.getInvoiceId());
            payment.setAmount(message.getAmount());
            payment.setPaymentDate(date);
            tryRepository.save(payment);
            log.info("✅ TRY payment saved.");
        } else if ("USD".equalsIgnoreCase(message.getCurrency())) {
            PaymentUSD payment = new PaymentUSD();
            payment.setInvoiceId(message.getInvoiceId());
            payment.setAmount(message.getAmount());
            payment.setPaymentDate(date);
            usdRepository.save(payment);
            log.info("✅ USD payment saved.");
        } else {
            log.error("❌ Unknown currency type: {}", message.getCurrency());
        }
    }
}
