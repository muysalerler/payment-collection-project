package com.collection.collectionservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.collection.collectionservice.entity.PaymentUSD;

public interface PaymentUSDRepository extends JpaRepository<PaymentUSD, Long> {
}
