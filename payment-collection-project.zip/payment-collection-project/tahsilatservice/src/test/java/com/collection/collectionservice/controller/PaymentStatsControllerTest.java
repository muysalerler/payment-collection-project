package com.collection.collectionservice.controller;

import com.collection.collectionservice.controller.PaymentStatsController;
import com.collection.collectionservice.entity.PaymentTRY;
import com.collection.collectionservice.entity.PaymentUSD;
import com.collection.collectionservice.repository.PaymentTRYRepository;
import com.collection.collectionservice.repository.PaymentUSDRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PaymentStatsController.class)
public class PaymentStatsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PaymentTRYRepository tryRepo;

    @MockBean
    private PaymentUSDRepository usdRepo;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void test_getStats_returnsCorrectSums() throws Exception {
        PaymentTRY t1 = new PaymentTRY();
        t1.setAmount(BigDecimal.valueOf(100));
        PaymentTRY t2 = new PaymentTRY();
        t2.setAmount(BigDecimal.valueOf(200));

        PaymentUSD u1 = new PaymentUSD();
        u1.setAmount(BigDecimal.valueOf(50));
        PaymentUSD u2 = new PaymentUSD();
        u2.setAmount(BigDecimal.valueOf(75));

        Mockito.when(tryRepo.findAll()).thenReturn(List.of(t1, t2));
        Mockito.when(usdRepo.findAll()).thenReturn(List.of(u1, u2));

        mockMvc.perform(get("/api/stats"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.try", is(300)))
                .andExpect(jsonPath("$.usd", is(125)));
    }

    @Test
    public void test_getLastPayments_returnsLast5Payments() throws Exception {
        PaymentTRY t1 = new PaymentTRY();
        t1.setInvoiceId(1L);
        t1.setAmount(BigDecimal.valueOf(100));
        t1.setPaymentDate(LocalDate.now());

        PaymentUSD u1 = new PaymentUSD();
        u1.setInvoiceId(2L);
        u1.setAmount(BigDecimal.valueOf(200));
        u1.setPaymentDate(LocalDate.now());

        Mockito.when(tryRepo.findAll()).thenReturn(List.of(t1));
        Mockito.when(usdRepo.findAll()).thenReturn(List.of(u1));

        mockMvc.perform(get("/api/last-payments"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.try[0]", hasKey("invoiceId")))
                .andExpect(jsonPath("$.usd[0]", hasKey("invoiceId")));
    }
}
