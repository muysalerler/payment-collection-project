package com.collection.collectionservice.kafka;

import com.collection.collectionservice.entity.PaymentTRY;
import com.collection.collectionservice.entity.PaymentUSD;
import com.collection.collectionservice.kafka.KafkaConsumerService;
import com.collection.collectionservice.model.PaymentMessage;
import com.collection.collectionservice.repository.PaymentTRYRepository;
import com.collection.collectionservice.repository.PaymentUSDRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class KafkaConsumerServiceTest {

    private PaymentTRYRepository tryRepository;
    private PaymentUSDRepository usdRepository;
    private KafkaConsumerService kafkaConsumerService;

    @BeforeEach
    public void setup() {
        tryRepository = mock(PaymentTRYRepository.class);
        usdRepository = mock(PaymentUSDRepository.class);
        kafkaConsumerService = new KafkaConsumerService(tryRepository, usdRepository);
    }

    @Test
    public void testConsume_TryCurrency_SavesToTRY() {
        PaymentMessage message = new PaymentMessage();
        message.setInvoiceId(100L);
        message.setAmount(BigDecimal.valueOf(200.50));
        message.setCurrency("TRY");
        message.setPaymentDate(LocalDate.now().toString());

        kafkaConsumerService.consume(message);

        ArgumentCaptor<PaymentTRY> captor = ArgumentCaptor.forClass(PaymentTRY.class);
        verify(tryRepository, times(1)).save(captor.capture());

        PaymentTRY saved = captor.getValue();
        assertEquals(100L, saved.getInvoiceId());
        assertEquals(BigDecimal.valueOf(200.50), saved.getAmount());
    }

    @Test
    public void testConsume_UsdCurrency_SavesToUSD() {
        PaymentMessage message = new PaymentMessage();
        message.setInvoiceId(200L);
        message.setAmount(BigDecimal.valueOf(50.00));
        message.setCurrency("USD");
        message.setPaymentDate(LocalDate.now().toString());

        kafkaConsumerService.consume(message);

        ArgumentCaptor<PaymentUSD> captor = ArgumentCaptor.forClass(PaymentUSD.class);
        verify(usdRepository, times(1)).save(captor.capture());

        PaymentUSD saved = captor.getValue();
        assertEquals(200L, saved.getInvoiceId());
        assertEquals(BigDecimal.valueOf(50.00), saved.getAmount());
    }

    @Test
    public void testConsume_InvalidCurrency_LogsError() {
        PaymentMessage message = new PaymentMessage();
        message.setInvoiceId(999L);
        message.setAmount(BigDecimal.valueOf(10));
        message.setCurrency("EUR");
        message.setPaymentDate(LocalDate.now().toString());

        kafkaConsumerService.consume(message);

        verifyNoInteractions(tryRepository);
        verifyNoInteractions(usdRepository);
    }
}
